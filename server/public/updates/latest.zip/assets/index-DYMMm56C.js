const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-B3KbyHoP.js","assets/index-Nhw_gYia.js","assets/index-D7ZWTEwN.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-Nhw_gYia.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-B3KbyHoP.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
