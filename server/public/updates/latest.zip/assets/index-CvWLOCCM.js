const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DqJ3nv_X.js","assets/index-CVeM-_1w.js","assets/index-D7ZWTEwN.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-CVeM-_1w.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-DqJ3nv_X.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
