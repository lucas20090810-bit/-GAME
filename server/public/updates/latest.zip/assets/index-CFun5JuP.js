const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-aLCwWgSj.js","assets/index-XiKZMtcZ.js","assets/index-M-I6sxbR.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-XiKZMtcZ.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-aLCwWgSj.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
